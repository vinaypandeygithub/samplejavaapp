package com.example.demo.restcontrollers;

import com.example.demo.models.Student;
import com.example.demo.repository.StudentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("api/Student")
public class StudentAPI {

    final StudentsRepository studentsRepository;

    @Autowired
    public StudentAPI(StudentsRepository studentsRepository) {
        this.studentsRepository = studentsRepository;
    }

    @RequestMapping(value = "All",method = RequestMethod.GET)
    public List<Student> GetListOfStudents()
    {
        List<Student> addresses = studentsRepository.findAll();
        return  addresses;
    }

    @RequestMapping(value = "Add",method = RequestMethod.POST)
    public Student AddStudent(@RequestBody Student student)
    {
        return  studentsRepository.save(student);
    }

    @RequestMapping(value = "Update",method = RequestMethod.PUT)
    public Student UpdateStudent(@RequestBody Student student)
    {
        return  studentsRepository.save(student);
    }

    @RequestMapping(value = "Delete",method = RequestMethod.GET)
    public void DeleteStudent(@RequestBody Student student)
    {
        studentsRepository.delete(student);
    }

}
