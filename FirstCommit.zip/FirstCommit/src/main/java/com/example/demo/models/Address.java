package com.example.demo.models;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table
public class Address {
    @Id
    @SequenceGenerator(name = "address_sequence",sequenceName = "address_sequence",initialValue = 1)
    @GeneratedValue(generator = "address_sequence",strategy = GenerationType.SEQUENCE)
    long id;
    String addressType;
    String address;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address1 = (Address) o;
        return id == address1.id && Objects.equals(address, address1.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, address);
    }
}
